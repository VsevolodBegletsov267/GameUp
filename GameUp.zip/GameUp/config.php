<?php

define('DB_HOST', 'localhost');
define('DB_NAME', 'simple_mvc_app');
define('DB_USER', 'root');
define('DB_PASS', '1029384756Seva');
